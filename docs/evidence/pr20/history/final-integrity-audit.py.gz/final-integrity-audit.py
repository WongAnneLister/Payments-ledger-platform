from pathlib import Path
import hashlib,json,re,gzip,tarfile,collections,datetime
root=Path.cwd();hist=root/'docs/evidence/pr20/history';secret=re.compile(rb'(?:sk_(?:test|live)_|whsec_)[A-Za-z0-9]{12,}')
sha=lambda b:hashlib.sha256(b).hexdigest();archives={};raw_count=0
for p in sorted(hist.glob('*.tar.gz')):
 hashes={}
 with tarfile.open(p) as t:
  for m in t:
   if not m.isfile():continue
   b=t.extractfile(m).read();assert not secret.search(b),f'Secret pattern in {p.name}/{m.name}';assert m.name not in hashes
   hashes[m.name]=sha(b);raw_count+=1
 archives[p.name]=hashes
verified=0;archive_verified=0
aliases={'same-instant-query-red-manifest.json':'same-instant-query-red-and-focused-restore-failure.tar.gz'}
for p in sorted(hist.glob('*manifest*.json')):
 d=json.loads(p.read_text())
 if isinstance(d,list):
  for x in d:
   name=x.get('file',x.get('archive'));expected=x.get('originalSha256')
   if expected:
    assert sha(gzip.decompress((hist/name).read_bytes()))==expected;verified+=1
  continue
 name=aliases.get(p.name,p.name.replace('-manifest.json','.tar.gz'));members=archives.get(name)
 if 'archiveSha256' in d:
  assert sha((hist/name).read_bytes())==d['archiveSha256'];archive_verified+=1
 if members is None:continue
 mapping=d.get('filesSha256',d.get('files',d.get('artifacts',{})))
 if isinstance(mapping,list):mapping={x['path']:x['sha256'] for x in mapping}
 for key,value in mapping.items():assert members.get(key)==value,(p.name,key);verified+=1
for p in sorted(hist.glob('*.gz')):
 if p.name.endswith('.tar.gz'):continue
 b=gzip.decompress(p.read_bytes());assert not secret.search(b),f'Secret pattern in {p.name}'
for p in sorted((root/'docs/evidence/pr20').rglob('*')):
 if p.is_file() and p.suffix in ['.json','.md','.txt','.ndjson','.csv']:assert not secret.search(p.read_bytes()),f'Secret pattern in {p}'
anchors=json.loads((hist/'source-anchors-current.json').read_text())['anchors']
for a in anchors:
 line=(root/a['source']).read_text().splitlines()[a['line']-1];assert line==a['sourceText'],a
p=root/'docs/english';diagrams=json.loads((p/'diagram-verification.json').read_text())['results']
for x in diagrams:
 blocks=re.findall(r'```mermaid\n(.*?)```',(p/x['sourceMarkdown']).read_text(),re.S)
 assert sha(blocks[x['sourceBlock']-1].encode())==x['mermaidSha256'];assert sha((p/x['export']).read_bytes())==x['pngSha256']
print(json.dumps({'status':'PASS','scope':'Archive byte hashes, secret-pattern scan, exact source anchors and Mermaid/PNG source hashes; no additional experiment PASS inferred','verifiedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archivesScanned':len(archives),'rawMembersScanned':raw_count,'manifestFileHashesVerified':verified,'archiveHashesVerified':archive_verified,'sourceAnchorsVerified':len(anchors),'diagramsVerified':len(diagrams)},indent=2))
